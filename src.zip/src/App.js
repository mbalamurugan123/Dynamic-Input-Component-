import './App.css';
import RegisterForm from './components/form';
function App() {
return (
  <div>
    <RegisterForm />
  </div>
);
}
export default App;